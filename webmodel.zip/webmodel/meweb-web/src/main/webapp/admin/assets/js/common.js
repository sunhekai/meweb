var pathName = window.location.pathname;
var hostinfo = window.location.host;
var contextPath = window.location.protocol +"//" + hostinfo + "/" + pathName.split("/",2)[1];
