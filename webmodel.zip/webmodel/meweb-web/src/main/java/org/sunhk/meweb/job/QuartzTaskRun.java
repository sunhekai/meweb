package org.sunhk.meweb.job;

public class QuartzTaskRun {
	public void execute()
	{
		System.out.println("job is running");
	}
}
